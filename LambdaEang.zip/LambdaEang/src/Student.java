

public class Student {
	
	private String name;
	private String major;
	private int numericIndicator;
	
	public Student(String name, String major) {
		this.name = name;
		this.major = major;
		this.numericIndicator = 0;
	}
	
	public int getNumericIndicator() {
		return numericIndicator;
	}
	
	public void setNumericIndicator(int numericIndicator) {
		this.numericIndicator = numericIndicator;
	}
	
	public String getName() {
		return name;
	}
	
	public String getMajor() {
		return major;
	}
	
	public void updateIndicator(int value) {
		this.numericIndicator = value;
	}
	
	@Override
	public String toString() {
		return this.name + ", Major: " + this.major + " numeric indicator: " + this.numericIndicator;
	}

}
