import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.*;

/** OOPDA HW11 Lambda Review
 * 
 * Student: Daniel Eang
 *Attribution: This assignment is done on my own with no additional help
 *Purpose: Use Lambda components to complete assignment 
 *@ author: Daniel Eang
 *@version: 11/15/25
 */

public class Lambda {
	
	private static int sum;

	public static void main(String[] args) {
		
		List<Student> students = new ArrayList<>();
		
		students.add(new Student("-Spike", "CS"));
		students.add(new Student("-John", "CS"));
		students.add(new Student("-Kiara", "Biology"));
		students.add(new Student("-Leonard", "English"));
		students.add(new Student("-Pablo", "CS"));
		students.add(new Student("-Clarissa", "Physics"));
		students.add(new Student("-Alyssa", "CS"));
		students.add(new Student("-Ian", "Engineering"));
		
		BiFunction<Integer, Integer, Integer> calcIndicator = (a, b) -> a + b;
		
		Predicate<Student> isCS = s -> s.getMajor().equals("CS");
		
		
		students.forEach(s-> {
			if (isCS.test(s)) {
				int randomValue1 = new Random().nextInt(10);
				int randomValue2 = new Random().nextInt(10);
				sum = calcIndicator.apply(randomValue1, randomValue2);
				s.setNumericIndicator(sum);
			} else {
				s.setNumericIndicator(0);
			}
			
			
		});
		
		
		System.out.println("Setting Random values with CS filter");
		System.out.println("Updated values:");
		students.forEach(System.out::println);
	}

}
