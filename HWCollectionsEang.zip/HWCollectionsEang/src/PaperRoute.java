import java.util.ArrayList;

public class PaperRoute {

	private ArrayList<Customer> customers;
	
	public PaperRoute() {
		customers = new ArrayList<>();
	}
	
	void addCustomer(String name, double amountDue, boolean hasDaily, boolean hasSunday) {
		
		Customer c = new Customer (name, amountDue, hasDaily, hasSunday);
		customers.add(c);
	}
	
	void displayAll() {
		for (Customer c: customers) {
			System.out.println(c);
		}
	}
	
	int countBySubscriptionType(String sn) {
		int count =0;
		
		for(Customer c : customers) {
			if (c.hasDaily()) {
				count++;
		} else {
			if (c.hasSunday()) {
					count++;
			}
		}
		}
		return count;
		
		
	}
	

	public double totDue() {
		double total = 0;
		for (Customer c : customers) {
			total += c.getamountDue();
		}
		return total;	
	}
	
	
}