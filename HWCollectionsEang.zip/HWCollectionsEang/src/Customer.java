

public class Customer {

	private String name;
	private double	amountDue;
	private boolean hasDaily;
	private boolean hasSunday;

	
	public Customer(String name, double	amountDue, boolean hasDaily, boolean hasSunday) {
		this.name = name;
		this.amountDue = amountDue;
		this.hasDaily = hasDaily;
		this.hasSunday = hasSunday;
	}

	public String getName() {
		return name;
	}
	
	public double getamountDue() {
		return amountDue;
	}
	
	public boolean hasDaily() {
		return hasDaily;
	}
	
	public boolean hasSunday() {
		return hasSunday;
	}
	
	public void setAmountDue(double amountDue) {
		this.amountDue = amountDue;
	}
	
	@Override
	public String toString() {
		return "Customer: " + name +  ", Amount	Due= $"	+ amountDue + ", Daily=" + hasDaily + ", Sunday=" + hasSunday;
	}

	
}
