/** OOPDA
 * 
 * Student: Daniel Eang
 *Attribution: Original with no help
 *Purpose: Creating a collection of Customer with the use of array to display data
 *@ author: Daniel Eang
 *@version: 09/09/25
 */


public class Tester {

	public static void main(String[] args) {
		
		PaperRoute myCusts = new PaperRoute();
		
		myCusts.addCustomer(" Dave", 50, true, true);
		myCusts.addCustomer(" Tori", 0, false, false);
		myCusts.addCustomer(" Sam", 50, true, true);
		myCusts.addCustomer(" Carl", 50, true, true);
		myCusts.addCustomer(" Mia", 0, false, false);

		System.out.println("Customers: ");
		myCusts.displayAll();
		System.out.println("Total amount due: $" + myCusts.totDue());
		System.out.println("Number of daily subs: " + myCusts.countBySubscriptionType("daily"));
		System.out.println("Number of Sunday subs: " + myCusts.countBySubscriptionType("Sunday"));

		
		myCusts.totDue();
		
	}
}
